import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Navigation from "./components/Navigation";
import Hero from "./components/Hero";
import Highlights from "./components/Highlights";
import Amenities from "./components/Amenities";
import PropertyDetails from "./components/PropertyDetails";
import Booking from "./components/Booking";
import Contact from "./components/Contact";
import Footer from "./components/Footer";

function MainLayout() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      <Hero />
      <Highlights />
      <Amenities />
      <PropertyDetails />
      <Booking />
      <Contact />
      <Footer />
    </div>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
      >
        <TooltipProvider>
          <Toaster />
          <MainLayout />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
