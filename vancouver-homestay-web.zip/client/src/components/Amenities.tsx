import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { Wifi, ParkingCircle, Flame, Wind, UtensilsCrossed, Waves, Tv, Leaf } from 'lucide-react';

export default function Amenities() {
  const { t } = useTranslation();

  const amenitiesList = [
    { icon: Wifi, label: t('amenities.wifi') },
    { icon: ParkingCircle, label: t('amenities.parking') },
    { icon: Flame, label: t('amenities.heating') },
    { icon: Wind, label: t('amenities.ac') },
    { icon: UtensilsCrossed, label: t('amenities.kitchen') },
    { icon: Waves, label: t('amenities.washer') },
    { icon: Tv, label: t('amenities.tv') },
    { icon: Leaf, label: t('amenities.garden') },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, scale: 0.8 },
    visible: {
      opacity: 1,
      scale: 1,
      transition: { duration: 0.5 },
    },
  };

  return (
    <section id="property" className="section-padding bg-gradient-to-br from-orange-50 to-white">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="section-title text-accent">{t('amenities.title')}</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-accent to-accent/50 mx-auto"></div>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-4 gap-6"
        >
          {amenitiesList.map((amenity, index) => {
            const Icon = amenity.icon;
            return (
              <motion.div
                key={index}
                variants={itemVariants}
                className="card-hover flex flex-col items-center justify-center p-6 bg-white rounded-xl border border-border hover:border-accent transition-all"
              >
                <Icon className="w-10 h-10 text-accent mb-3" />
                <p className="text-center text-sm font-medium text-foreground">{amenity.label}</p>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}
