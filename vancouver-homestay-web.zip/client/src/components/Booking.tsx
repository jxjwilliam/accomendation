import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';
import { Calendar } from 'lucide-react';

export default function Booking() {
  const { t } = useTranslation();
  const createBooking = trpc.bookings.create.useMutation();
  const [formData, setFormData] = useState({
    guestName: '',
    guestEmail: '',
    guestPhone: '',
    checkInDate: '',
    checkOutDate: '',
    numberOfGuests: 1,
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'numberOfGuests' ? parseInt(value) : value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.guestName || !formData.guestEmail || !formData.checkInDate || !formData.checkOutDate) {
      toast.error(t('booking.error'));
      return;
    }

    try {
      const checkInDate = new Date(formData.checkInDate);
      const checkOutDate = new Date(formData.checkOutDate);
      const nights = Math.ceil((checkOutDate.getTime() - checkInDate.getTime()) / (1000 * 60 * 60 * 24));
      const pricePerNight = 150; // Example price
      const totalPrice = nights * pricePerNight;

      await createBooking.mutateAsync({
        guestName: formData.guestName,
        guestEmail: formData.guestEmail,
        guestPhone: formData.guestPhone,
        checkInDate,
        checkOutDate,
        numberOfGuests: formData.numberOfGuests,
        totalPrice,
      });

      toast.success(t('booking.success'));
      setFormData({
        guestName: '',
        guestEmail: '',
        guestPhone: '',
        checkInDate: '',
        checkOutDate: '',
        numberOfGuests: 1,
      });
    } catch (error) {
      toast.error(t('booking.error'));
    }
  };

  return (
    <section id="booking" className="section-padding bg-white">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="section-title text-accent">{t('booking.title')}</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-accent to-accent/50 mx-auto"></div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-2xl mx-auto"
        >
          <div className="bg-gradient-to-br from-orange-50 to-white p-8 md:p-12 rounded-2xl border border-border shadow-lg">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Guest Information */}
              <div className="space-y-4">
                <h3 className="font-semibold text-lg text-foreground">Guest Information</h3>
                <Input
                  type="text"
                  name="guestName"
                  placeholder={t('booking.name')}
                  value={formData.guestName}
                  onChange={handleChange}
                  required
                  className="border-border"
                />
                <Input
                  type="email"
                  name="guestEmail"
                  placeholder={t('booking.email')}
                  value={formData.guestEmail}
                  onChange={handleChange}
                  required
                  className="border-border"
                />
                <Input
                  type="tel"
                  name="guestPhone"
                  placeholder={t('booking.phone')}
                  value={formData.guestPhone}
                  onChange={handleChange}
                  className="border-border"
                />
              </div>

              {/* Booking Dates */}
              <div className="space-y-4">
                <h3 className="font-semibold text-lg text-foreground flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-accent" />
                  Booking Dates
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-foreground">{t('booking.checkIn')}</label>
                    <Input
                      type="date"
                      name="checkInDate"
                      value={formData.checkInDate}
                      onChange={handleChange}
                      required
                      className="border-border mt-1"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-foreground">{t('booking.checkOut')}</label>
                    <Input
                      type="date"
                      name="checkOutDate"
                      value={formData.checkOutDate}
                      onChange={handleChange}
                      required
                      className="border-border mt-1"
                    />
                  </div>
                </div>
              </div>

              {/* Number of Guests */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">{t('booking.guests')}</label>
                <select
                  name="numberOfGuests"
                  value={formData.numberOfGuests}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent"
                >
                  {[1, 2, 3, 4, 5, 6, 7, 8].map(num => (
                    <option key={num} value={num}>{num} {num === 1 ? 'Guest' : 'Guests'}</option>
                  ))}
                </select>
              </div>

              {/* Submit Button */}
              <Button
                type="submit"
                disabled={createBooking.isPending}
                className="w-full bg-accent hover:bg-accent/90 text-white py-6 text-lg font-semibold"
              >
                {createBooking.isPending ? 'Booking...' : t('booking.submit')}
              </Button>
            </form>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
