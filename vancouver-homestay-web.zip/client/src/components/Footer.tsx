import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { Heart } from 'lucide-react';

export default function Footer() {
  const { t } = useTranslation();
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-foreground text-white py-12">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8"
        >
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">🏠</span>
              </div>
              <span className="font-bold text-xl">Surrey Home</span>
            </div>
            <p className="text-white/70 text-sm">
              Experience luxury and comfort in beautiful Surrey, British Columbia.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold text-lg mb-4">Quick Links</h3>
            <ul className="space-y-2 text-white/70 text-sm">
              <li><a href="#home" className="hover:text-accent transition-colors">Home</a></li>
              <li><a href="#property" className="hover:text-accent transition-colors">Property</a></li>
              <li><a href="#booking" className="hover:text-accent transition-colors">Booking</a></li>
              <li><a href="#contact" className="hover:text-accent transition-colors">Contact</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="font-semibold text-lg mb-4">Contact</h3>
            <ul className="space-y-2 text-white/70 text-sm">
              <li>📍 16727 108 Avenue, Surrey BC V4N 1N5</li>
              <li>📞 +1 (604) 555-0123</li>
              <li>📧 info@surreyhomestay.com</li>
            </ul>
          </div>
        </motion.div>

        {/* Divider */}
        <div className="border-t border-white/20 my-8"></div>

        {/* Bottom Section */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="flex flex-col md:flex-row items-center justify-between text-white/70 text-sm"
        >
          <div className="flex items-center gap-1 mb-4 md:mb-0">
            <span>© {currentYear} Surrey Home-stay. {t('footer.rights')}.</span>
            <Heart className="w-4 h-4 text-accent fill-accent" />
          </div>
          <div className="flex gap-6">
            <a href="#" className="hover:text-accent transition-colors">{t('footer.privacy')}</a>
            <a href="#" className="hover:text-accent transition-colors">{t('footer.terms')}</a>
          </div>
        </motion.div>
      </div>
    </footer>
  );
}
