import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { Bed, UtensilsCrossed, MapPin, Sparkles } from 'lucide-react';

export default function Highlights() {
  const { t } = useTranslation();

  const highlights = [
    {
      icon: Bed,
      title: t('highlights.bedrooms'),
      description: 'Comfortable and spacious rooms for a relaxing stay',
    },
    {
      icon: UtensilsCrossed,
      title: t('highlights.kitchen'),
      description: 'Fully equipped modern kitchen for your convenience',
    },
    {
      icon: MapPin,
      title: t('highlights.location'),
      description: 'Perfect location in Surrey with easy access to attractions',
    },
    {
      icon: Sparkles,
      title: t('highlights.amenities'),
      description: 'Premium amenities for a luxurious experience',
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  return (
    <section className="section-padding bg-white">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="section-title text-accent">{t('highlights.title')}</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-accent to-accent/50 mx-auto"></div>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
        >
          {highlights.map((item, index) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={index}
                variants={itemVariants}
                className="card-hover bg-gradient-to-br from-white to-orange-50 p-8 rounded-xl border border-border text-center"
              >
                <div className="inline-flex items-center justify-center w-16 h-16 bg-accent/10 rounded-full mb-4">
                  <Icon className="w-8 h-8 text-accent" />
                </div>
                <h3 className="text-xl font-bold mb-2 text-foreground">{item.title}</h3>
                <p className="text-muted-foreground text-sm">{item.description}</p>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}
