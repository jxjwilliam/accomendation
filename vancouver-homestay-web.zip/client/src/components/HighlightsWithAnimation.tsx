import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import ScrollAnimationWrapper from './ScrollAnimationWrapper';
import { MapPin, Users, Wifi, Coffee } from 'lucide-react';

export default function HighlightsWithAnimation() {
  const { t } = useTranslation();

  const highlights = [
    {
      icon: MapPin,
      titleKey: 'highlights.location',
      descKey: 'highlights.locationDesc',
    },
    {
      icon: Users,
      titleKey: 'highlights.capacity',
      descKey: 'highlights.capacityDesc',
    },
    {
      icon: Wifi,
      titleKey: 'highlights.amenities',
      descKey: 'highlights.amenitiesDesc',
    },
    {
      icon: Coffee,
      titleKey: 'highlights.comfort',
      descKey: 'highlights.comfortDesc',
    },
  ];

  return (
    <section className="section-padding bg-gradient-to-b from-white to-orange-50">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="section-title text-accent">{t('highlights.title')}</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-accent to-accent/50 mx-auto"></div>
        </motion.div>

        <ScrollAnimationWrapper animationType="fade-up" stagger={0.15}>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {highlights.map((highlight, index) => {
              const Icon = highlight.icon;
              return (
                <div
                  key={index}
                  data-scroll-animate="fade-up"
                  className="card-hover bg-white p-8 rounded-xl border border-border shadow-md hover:shadow-lg transition-all duration-300"
                >
                  <div className="w-14 h-14 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                    <Icon className="w-7 h-7 text-accent" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-2">
                    {t(highlight.titleKey)}
                  </h3>
                  <p className="text-muted-foreground text-sm">
                    {t(highlight.descKey)}
                  </p>
                </div>
              );
            })}
          </div>
        </ScrollAnimationWrapper>
      </div>
    </section>
  );
}
