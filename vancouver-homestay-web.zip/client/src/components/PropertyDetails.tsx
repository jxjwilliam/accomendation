import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { Star, Users, DoorOpen, Wifi } from 'lucide-react';

export default function PropertyDetails() {
  const { t } = useTranslation();

  const rooms = [
    {
      name: 'Master Bedroom',
      capacity: 2,
      image: 'https://images.unsplash.com/photo-1631049307038-da0ec9d70304?w=400&h=300&fit=crop',
      amenities: ['King Bed', 'Ensuite Bathroom', 'Smart TV', 'WiFi'],
    },
    {
      name: 'Guest Bedroom',
      capacity: 2,
      image: 'https://images.unsplash.com/photo-1631049307038-da0ec9d70304?w=400&h=300&fit=crop',
      amenities: ['Queen Bed', 'Shared Bathroom', 'Smart TV', 'WiFi'],
    },
    {
      name: 'Living Room',
      capacity: 4,
      image: 'https://images.unsplash.com/photo-1631049307038-da0ec9d70304?w=400&h=300&fit=crop',
      amenities: ['Comfortable Seating', 'Smart TV', 'Fireplace', 'WiFi'],
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  return (
    <section className="section-padding bg-white">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="section-title text-accent">{t('property.title')}</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-accent to-accent/50 mx-auto"></div>
          <p className="text-muted-foreground mt-4 max-w-2xl mx-auto">
            {t('property.description')}
          </p>
        </motion.div>

        {/* Rooms Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16"
        >
          {rooms.map((room, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              className="card-hover rounded-xl overflow-hidden border border-border shadow-lg"
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={room.image}
                  alt={room.name}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-foreground mb-2">{room.name}</h3>
                <div className="flex items-center gap-2 text-muted-foreground mb-4">
                  <Users className="w-4 h-4" />
                  <span className="text-sm">Capacity: {room.capacity} guests</span>
                </div>
                <div className="space-y-2">
                  {room.amenities.map((amenity, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <div className="w-1.5 h-1.5 rounded-full bg-accent"></div>
                      {amenity}
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* House Rules */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="bg-gradient-to-br from-orange-50 to-white p-8 rounded-2xl border border-border"
        >
          <h3 className="text-2xl font-bold text-foreground mb-6">{t('property.rules')}</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <div className="flex gap-3">
                <div className="w-6 h-6 rounded-full bg-accent/10 flex items-center justify-center flex-shrink-0 mt-1">
                  <div className="w-2 h-2 rounded-full bg-accent"></div>
                </div>
                <div>
                  <h4 className="font-semibold text-foreground">Check-in & Check-out</h4>
                  <p className="text-sm text-muted-foreground">Check-in after 3 PM, Check-out before 11 AM</p>
                </div>
              </div>
              <div className="flex gap-3">
                <div className="w-6 h-6 rounded-full bg-accent/10 flex items-center justify-center flex-shrink-0 mt-1">
                  <div className="w-2 h-2 rounded-full bg-accent"></div>
                </div>
                <div>
                  <h4 className="font-semibold text-foreground">No Smoking</h4>
                  <p className="text-sm text-muted-foreground">Smoking is strictly prohibited inside the property</p>
                </div>
              </div>
              <div className="flex gap-3">
                <div className="w-6 h-6 rounded-full bg-accent/10 flex items-center justify-center flex-shrink-0 mt-1">
                  <div className="w-2 h-2 rounded-full bg-accent"></div>
                </div>
                <div>
                  <h4 className="font-semibold text-foreground">Quiet Hours</h4>
                  <p className="text-sm text-muted-foreground">Please keep noise levels down after 10 PM</p>
                </div>
              </div>
            </div>
            <div className="space-y-3">
              <div className="flex gap-3">
                <div className="w-6 h-6 rounded-full bg-accent/10 flex items-center justify-center flex-shrink-0 mt-1">
                  <div className="w-2 h-2 rounded-full bg-accent"></div>
                </div>
                <div>
                  <h4 className="font-semibold text-foreground">Pets</h4>
                  <p className="text-sm text-muted-foreground">Pets are not allowed without prior approval</p>
                </div>
              </div>
              <div className="flex gap-3">
                <div className="w-6 h-6 rounded-full bg-accent/10 flex items-center justify-center flex-shrink-0 mt-1">
                  <div className="w-2 h-2 rounded-full bg-accent"></div>
                </div>
                <div>
                  <h4 className="font-semibold text-foreground">Parties</h4>
                  <p className="text-sm text-muted-foreground">No parties or large gatherings allowed</p>
                </div>
              </div>
              <div className="flex gap-3">
                <div className="w-6 h-6 rounded-full bg-accent/10 flex items-center justify-center flex-shrink-0 mt-1">
                  <div className="w-2 h-2 rounded-full bg-accent"></div>
                </div>
                <div>
                  <h4 className="font-semibold text-foreground">Respect Property</h4>
                  <p className="text-sm text-muted-foreground">Please treat the property with care and respect</p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
