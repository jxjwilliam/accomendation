import React, { useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface ScrollAnimationWrapperProps {
  children: React.ReactNode;
  animationType?: 'fade-up' | 'fade-down' | 'fade-left' | 'fade-right' | 'scale' | 'rotate';
  duration?: number;
  delay?: number;
  stagger?: number;
  className?: string;
}

export default function ScrollAnimationWrapper({
  children,
  animationType = 'fade-up',
  duration = 0.8,
  delay = 0,
  stagger = 0.1,
  className = '',
}: ScrollAnimationWrapperProps) {
  const containerRef = React.useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    const elements = containerRef.current.querySelectorAll('[data-scroll-animate]');
    
    elements.forEach((element, index) => {
      const elementAnimationType = (element as HTMLElement).dataset.scrollAnimate || animationType;
      
      let fromVars: gsap.TweenVars = {};
      let toVars: gsap.TweenVars = {
        opacity: 1,
        duration,
        ease: 'power3.out',
      };

      switch (elementAnimationType) {
        case 'fade-up':
          fromVars = { opacity: 0, y: 50 };
          toVars.y = 0;
          break;
        case 'fade-down':
          fromVars = { opacity: 0, y: -50 };
          toVars.y = 0;
          break;
        case 'fade-left':
          fromVars = { opacity: 0, x: -50 };
          toVars.x = 0;
          break;
        case 'fade-right':
          fromVars = { opacity: 0, x: 50 };
          toVars.x = 0;
          break;
        case 'scale':
          fromVars = { opacity: 0, scale: 0.8 };
          toVars.scale = 1;
          break;
        case 'rotate':
          fromVars = { opacity: 0, rotation: -10 };
          toVars.rotation = 0;
          break;
        default:
          fromVars = { opacity: 0 };
      }

      gsap.fromTo(
        element,
        fromVars,
        {
          ...toVars,
          scrollTrigger: {
            trigger: element,
            start: 'top 85%',
            end: 'top 55%',
            scrub: false,
            markers: false,
          },
          delay: delay + (index * stagger),
        }
      );
    });

    return () => {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, [animationType, duration, delay, stagger]);

  return (
    <div ref={containerRef} className={className}>
      {children}
    </div>
  );
}
