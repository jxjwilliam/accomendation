import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export function useScrollAnimation(options?: {
  duration?: number;
  delay?: number;
  stagger?: number;
  ease?: string;
}) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    const elements = containerRef.current.querySelectorAll('[data-scroll]');
    
    elements.forEach((element, index) => {
      const animationType = (element as HTMLElement).dataset.scroll || 'fade-up';
      
      let fromVars: gsap.TweenVars = {};
      let toVars: gsap.TweenVars = {
        opacity: 1,
        duration: options?.duration || 0.8,
        ease: options?.ease || 'power3.out',
      };

      switch (animationType) {
        case 'fade-up':
          fromVars = { opacity: 0, y: 50 };
          break;
        case 'fade-down':
          fromVars = { opacity: 0, y: -50 };
          break;
        case 'fade-left':
          fromVars = { opacity: 0, x: -50 };
          break;
        case 'fade-right':
          fromVars = { opacity: 0, x: 50 };
          break;
        case 'scale':
          fromVars = { opacity: 0, scale: 0.8 };
          break;
        case 'rotate':
          fromVars = { opacity: 0, rotation: -10 };
          break;
        default:
          fromVars = { opacity: 0 };
      }

      gsap.fromTo(
        element,
        fromVars,
        {
          ...toVars,
          scrollTrigger: {
            trigger: element,
            start: 'top 80%',
            end: 'top 50%',
            scrub: false,
            markers: false,
          },
          delay: (options?.delay || 0) + (index * (options?.stagger || 0.1)),
        }
      );
    });

    return () => {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, [options?.duration, options?.delay, options?.stagger, options?.ease]);

  return containerRef;
}
