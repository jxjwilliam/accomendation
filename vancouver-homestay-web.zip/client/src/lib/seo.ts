export interface SEOMetaTags {
  title: string;
  description: string;
  keywords?: string[];
  ogTitle?: string;
  ogDescription?: string;
  ogImage?: string;
  ogUrl?: string;
  ogType?: string;
  twitterCard?: string;
  twitterTitle?: string;
  twitterDescription?: string;
  twitterImage?: string;
  canonicalUrl?: string;
  author?: string;
  robots?: string;
  viewport?: string;
  charset?: string;
}

export const setSEOMetaTags = (tags: SEOMetaTags) => {
  // Set title
  document.title = tags.title;

  // Helper function to set or update meta tag
  const setMeta = (name: string, content: string, isProperty = false) => {
    let element = document.querySelector(
      isProperty ? `meta[property="${name}"]` : `meta[name="${name}"]`
    );

    if (!element) {
      element = document.createElement('meta');
      if (isProperty) {
        element.setAttribute('property', name);
      } else {
        element.setAttribute('name', name);
      }
      document.head.appendChild(element);
    }

    element.setAttribute('content', content);
  };

  // Set basic meta tags
  setMeta('description', tags.description);
  if (tags.keywords) {
    setMeta('keywords', tags.keywords.join(', '));
  }
  if (tags.author) {
    setMeta('author', tags.author);
  }
  if (tags.robots) {
    setMeta('robots', tags.robots);
  }

  // Set Open Graph tags
  setMeta('og:title', tags.ogTitle || tags.title, true);
  setMeta('og:description', tags.ogDescription || tags.description, true);
  if (tags.ogImage) {
    setMeta('og:image', tags.ogImage, true);
  }
  if (tags.ogUrl) {
    setMeta('og:url', tags.ogUrl, true);
  }
  setMeta('og:type', tags.ogType || 'website', true);

  // Set Twitter Card tags
  setMeta('twitter:card', tags.twitterCard || 'summary_large_image');
  setMeta('twitter:title', tags.twitterTitle || tags.title);
  setMeta('twitter:description', tags.twitterDescription || tags.description);
  if (tags.twitterImage) {
    setMeta('twitter:image', tags.twitterImage);
  }

  // Set canonical URL
  if (tags.canonicalUrl) {
    let canonical = document.querySelector('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.setAttribute('rel', 'canonical');
      document.head.appendChild(canonical);
    }
    canonical.setAttribute('href', tags.canonicalUrl);
  }
};

// Structured data for JSON-LD
export interface StructuredData {
  '@context': string;
  '@type': string;
  [key: string]: any;
}

export const setStructuredData = (data: StructuredData) => {
  let script = document.querySelector('script[type="application/ld+json"]');

  if (!script) {
    script = document.createElement('script');
    script.setAttribute('type', 'application/ld+json');
    document.head.appendChild(script);
  }

  script.textContent = JSON.stringify(data);
};

// Property-specific SEO
export const getPropertySEOTags = (): SEOMetaTags => {
  return {
    title: 'Surrey Home-stay - Luxury Vacation Rental in British Columbia',
    description: 'Experience luxury and comfort at our beautiful home-stay in Surrey, BC. Perfect for families and travelers. Book now for an unforgettable stay.',
    keywords: [
      'vacation rental',
      'home-stay',
      'Surrey BC',
      'accommodation',
      'luxury rental',
      'British Columbia',
      'Airbnb alternative',
      'short-term rental',
    ],
    ogTitle: 'Surrey Home-stay - Luxury Vacation Rental',
    ogDescription: 'Experience luxury and comfort at our beautiful home-stay in Surrey, BC. Perfect for families and travelers.',
    ogType: 'website',
    twitterCard: 'summary_large_image',
    author: 'Surrey Home-stay',
    robots: 'index, follow',
    canonicalUrl: typeof window !== 'undefined' ? window.location.href : '',
  };
};

// Booking page SEO
export const getBookingSEOTags = (): SEOMetaTags => {
  return {
    title: 'Book Your Stay - Surrey Home-stay | Luxury Vacation Rental',
    description: 'Book your perfect vacation at Surrey Home-stay. Check availability, select dates, and reserve your room today.',
    keywords: [
      'book vacation',
      'reserve home-stay',
      'Surrey accommodation',
      'vacation booking',
    ],
    robots: 'index, follow',
  };
};

// Contact page SEO
export const getContactSEOTags = (): SEOMetaTags => {
  return {
    title: 'Contact Us - Surrey Home-stay',
    description: 'Get in touch with Surrey Home-stay. We are located at 16727 108 Avenue, Surrey BC V4N 1N5. Contact us for inquiries and reservations.',
    keywords: [
      'contact',
      'Surrey BC',
      'home-stay contact',
      'vacation rental inquiry',
    ],
    robots: 'index, follow',
  };
};

// Property structured data for search engines
export const getPropertyStructuredData = (): StructuredData => {
  return {
    '@context': 'https://schema.org',
    '@type': 'VacationRental',
    name: 'Surrey Home-stay',
    description: 'Luxury vacation rental in Surrey, British Columbia',
    image: 'https://images.unsplash.com/photo-1631049307038-da0ec9d70304?w=1200',
    address: {
      '@type': 'PostalAddress',
      streetAddress: '16727 108 Avenue',
      addressLocality: 'Surrey',
      addressRegion: 'BC',
      postalCode: 'V4N 1N5',
      addressCountry: 'CA',
    },
    telephone: '+1 (604) 555-0123',
    email: 'info@surreyhomestay.com',
    url: 'https://surreyhomestay.com',
    priceRange: '$$',
    aggregateRating: {
      '@type': 'AggregateRating',
      ratingValue: '4.8',
      reviewCount: '156',
    },
    amenityFeature: [
      {
        '@type': 'Text',
        name: 'WiFi',
      },
      {
        '@type': 'Text',
        name: 'Kitchen',
      },
      {
        '@type': 'Text',
        name: 'Parking',
      },
    ],
  };
};
