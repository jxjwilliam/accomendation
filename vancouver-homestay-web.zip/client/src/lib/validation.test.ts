import { describe, expect, it } from 'vitest';
import {
  validateEmail,
  validatePhone,
  validateBookingForm,
  validateContactForm,
  sanitizeInput,
} from './validation';

describe('Validation Utilities', () => {
  describe('validateEmail', () => {
    it('should validate correct email addresses', () => {
      expect(validateEmail('test@example.com')).toBe(true);
      expect(validateEmail('user.name@domain.co.uk')).toBe(true);
    });

    it('should reject invalid email addresses', () => {
      expect(validateEmail('invalid.email')).toBe(false);
      expect(validateEmail('test@')).toBe(false);
      expect(validateEmail('@example.com')).toBe(false);
    });
  });

  describe('validatePhone', () => {
    it('should validate phone numbers', () => {
      expect(validatePhone('+1 (604) 555-0123')).toBe(true);
      expect(validatePhone('604-555-0123')).toBe(true);
      expect(validatePhone('6045550123')).toBe(true);
    });

    it('should reject invalid phone numbers', () => {
      expect(validatePhone('123')).toBe(false);
      expect(validatePhone('abc')).toBe(false);
    });
  });

  describe('validateBookingForm', () => {
    it('should validate complete booking form', () => {
      const checkIn = new Date();
      checkIn.setDate(checkIn.getDate() + 5);
      const checkOut = new Date(checkIn);
      checkOut.setDate(checkOut.getDate() + 3);

      const result = validateBookingForm({
        guestName: 'John Doe',
        guestEmail: 'john@example.com',
        checkInDate: checkIn,
        checkOutDate: checkOut,
        numberOfGuests: 2,
      });

      expect(result.isValid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it('should reject booking with past check-in date', () => {
      const checkIn = new Date();
      checkIn.setDate(checkIn.getDate() - 1);
      const checkOut = new Date(checkIn);
      checkOut.setDate(checkOut.getDate() + 3);

      const result = validateBookingForm({
        guestName: 'John Doe',
        guestEmail: 'john@example.com',
        checkInDate: checkIn,
        checkOutDate: checkOut,
        numberOfGuests: 2,
      });

      expect(result.isValid).toBe(false);
      expect(result.errors.some(e => e.field === 'checkInDate')).toBe(true);
    });

    it('should reject booking with invalid guest count', () => {
      const checkIn = new Date();
      checkIn.setDate(checkIn.getDate() + 5);
      const checkOut = new Date(checkIn);
      checkOut.setDate(checkOut.getDate() + 3);

      const result = validateBookingForm({
        guestName: 'John Doe',
        guestEmail: 'john@example.com',
        checkInDate: checkIn,
        checkOutDate: checkOut,
        numberOfGuests: 15,
      });

      expect(result.isValid).toBe(false);
      expect(result.errors.some(e => e.field === 'numberOfGuests')).toBe(true);
    });
  });

  describe('validateContactForm', () => {
    it('should validate complete contact form', () => {
      const result = validateContactForm({
        name: 'Jane Smith',
        email: 'jane@example.com',
        message: 'This is a valid message with more than 10 characters',
      });

      expect(result.isValid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it('should reject short message', () => {
      const result = validateContactForm({
        name: 'Jane Smith',
        email: 'jane@example.com',
        message: 'Short',
      });

      expect(result.isValid).toBe(false);
      expect(result.errors.some(e => e.field === 'message')).toBe(true);
    });
  });

  describe('sanitizeInput', () => {
    it('should sanitize HTML input', () => {
      const input = '<script>alert("xss")</script>';
      const sanitized = sanitizeInput(input);
      expect(sanitized).not.toContain('<script>');
    });
  });
});
