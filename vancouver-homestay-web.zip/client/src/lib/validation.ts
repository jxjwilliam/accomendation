export interface ValidationError {
  field: string;
  message: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
}

// Email validation
export const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

// Phone validation (basic international format)
export const validatePhone = (phone: string): boolean => {
  const phoneRegex = /^[\d\s\-\+\(\)]{10,}$/;
  return phoneRegex.test(phone);
};

// Booking form validation
export const validateBookingForm = (data: {
  guestName?: string;
  guestEmail?: string;
  checkInDate?: Date;
  checkOutDate?: Date;
  numberOfGuests?: number;
}): ValidationResult => {
  const errors: ValidationError[] = [];

  if (!data.guestName || data.guestName.trim().length < 2) {
    errors.push({
      field: 'guestName',
      message: 'Guest name must be at least 2 characters',
    });
  }

  if (!data.guestEmail || !validateEmail(data.guestEmail)) {
    errors.push({
      field: 'guestEmail',
      message: 'Please enter a valid email address',
    });
  }

  if (!data.checkInDate) {
    errors.push({
      field: 'checkInDate',
      message: 'Check-in date is required',
    });
  }

  if (!data.checkOutDate) {
    errors.push({
      field: 'checkOutDate',
      message: 'Check-out date is required',
    });
  }

  if (data.checkInDate && data.checkOutDate) {
    if (data.checkInDate >= data.checkOutDate) {
      errors.push({
        field: 'checkOutDate',
        message: 'Check-out date must be after check-in date',
      });
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    if (data.checkInDate < today) {
      errors.push({
        field: 'checkInDate',
        message: 'Check-in date cannot be in the past',
      });
    }
  }

  if (!data.numberOfGuests || data.numberOfGuests < 1 || data.numberOfGuests > 10) {
    errors.push({
      field: 'numberOfGuests',
      message: 'Number of guests must be between 1 and 10',
    });
  }

  return {
    isValid: errors.length === 0,
    errors,
  };
};

// Contact form validation
export const validateContactForm = (data: {
  name?: string;
  email?: string;
  message?: string;
}): ValidationResult => {
  const errors: ValidationError[] = [];

  if (!data.name || data.name.trim().length < 2) {
    errors.push({
      field: 'name',
      message: 'Name must be at least 2 characters',
    });
  }

  if (!data.email || !validateEmail(data.email)) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address',
    });
  }

  if (!data.message || data.message.trim().length < 10) {
    errors.push({
      field: 'message',
      message: 'Message must be at least 10 characters',
    });
  }

  if (data.message && data.message.length > 5000) {
    errors.push({
      field: 'message',
      message: 'Message must not exceed 5000 characters',
    });
  }

  return {
    isValid: errors.length === 0,
    errors,
  };
};

// Sanitize input to prevent XSS
export const sanitizeInput = (input: string): string => {
  const div = document.createElement('div');
  div.textContent = input;
  return div.innerHTML;
};
