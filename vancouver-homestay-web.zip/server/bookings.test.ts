import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("bookings", () => {
  it("creates a booking with valid input", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const checkInDate = new Date("2026-03-15");
    const checkOutDate = new Date("2026-03-20");

    const result = await caller.bookings.create({
      guestName: "John Doe",
      guestEmail: "john@example.com",
      guestPhone: "+1234567890",
      checkInDate,
      checkOutDate,
      numberOfGuests: 2,
      totalPrice: 750,
    });

    expect(result).toBeDefined();
  });

  it("lists all bookings", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const bookings = await caller.bookings.list();
    expect(Array.isArray(bookings)).toBe(true);
  });
});
