import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("contact", () => {
  it("submits a contact form with valid input", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.contact.submit({
      name: "Jane Smith",
      email: "jane@example.com",
      phone: "+1987654321",
      message: "I would like to inquire about your property",
      language: "en",
    });

    expect(result).toBeDefined();
  });

  it("submits a contact form in Chinese", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.contact.submit({
      name: "李明",
      email: "liming@example.com",
      message: "我想了解更多关于您的房产",
      language: "zh-CN",
    });

    expect(result).toBeDefined();
  });

  it("lists all contact submissions", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const submissions = await caller.contact.list();
    expect(Array.isArray(submissions)).toBe(true);
  });
});
