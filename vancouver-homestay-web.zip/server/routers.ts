import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { getAllAmenities, getAllRooms, createBooking, getAllBookings, createContactSubmission, getAllContactSubmissions } from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Property data routers
  amenities: router({
    list: publicProcedure.query(async () => {
      return getAllAmenities();
    }),
  }),

  rooms: router({
    list: publicProcedure.query(async () => {
      return getAllRooms();
    }),
  }),

  // Booking routers
  bookings: router({
    create: publicProcedure
      .input(z.object({
        guestName: z.string().min(1),
        guestEmail: z.string().email(),
        guestPhone: z.string().min(1),
        checkInDate: z.date(),
        checkOutDate: z.date(),
        numberOfGuests: z.number().int().positive(),
        totalPrice: z.number().positive(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return createBooking({
          guestName: input.guestName,
          guestEmail: input.guestEmail,
          guestPhone: input.guestPhone,
          checkInDate: input.checkInDate,
          checkOutDate: input.checkOutDate,
          numberOfGuests: input.numberOfGuests,
          totalPrice: input.totalPrice.toString(),
          notes: input.notes,
          status: 'pending',
        });
      }),

    list: publicProcedure.query(async () => {
      return getAllBookings();
    }),
  }),

  // Contact submissions routers
  contact: router({
    submit: publicProcedure
      .input(z.object({
        name: z.string().min(1),
        email: z.string().email(),
        phone: z.string().optional(),
        message: z.string().min(1),
        language: z.enum(['en', 'zh-CN', 'zh-TW']).default('en'),
      }))
      .mutation(async ({ input }) => {
        return createContactSubmission({
          name: input.name,
          email: input.email,
          phone: input.phone,
          message: input.message,
          language: input.language,
          status: 'new',
        });
      }),

    list: publicProcedure.query(async () => {
      return getAllContactSubmissions();
    }),
  }),
});

export type AppRouter = typeof appRouter;
